<?php
// Define the path to the 'upi.txt' file
$file_path = 'upi.txt';

// Check if the file exists and is readable
if (!file_exists($file_path) || !is_readable($file_path)) {
    // If the file doesn't exist or isn't readable, return an error response
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Payment details file not found or not readable.'
    ]);
    exit;
}

// Read the contents of the 'upi.txt' file
$file_contents = file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

// Check if the file has the correct number of lines (4 lines)
if (count($file_contents) < 4) {
    // If the file doesn't have the correct format, return an error
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid payment details file format.'
    ]);
    exit;
}

// Extract payment details from the file
$upiId = trim($file_contents[0]);
$siteName = trim($file_contents[1]);
$transactionRef = trim($file_contents[2]);
$merchantCode = trim($file_contents[3]);

// Return the payment details as a JSON response
header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'data' => [
        'upiId' => $upiId,
        'siteName' => $siteName,
        'transactionRef' => $transactionRef,
        'merchantCode' => $merchantCode
    ]
]);
