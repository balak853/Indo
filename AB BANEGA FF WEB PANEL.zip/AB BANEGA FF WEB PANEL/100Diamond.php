<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mobile Responsive Header with Search Bar and Image Slider</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #13182b; /* Matches header background */
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #13182b;
      padding: 10px;
      color: white;
    }

    .header .logo {
      font-size: 1.2rem;
      font-weight: bold;
      display: flex;
      align-items: center;
    }

    .header .logo span {
      color: orange;
    }

    .header .language {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .header .language img {
      width: 20px;
      height: 20px;
      border-radius: 50%;
    }

    .header .language button {
      background-color: #3b4a5a;
      color: white;
      border: none;
      border-radius: 5px;
      padding: 5px 10px;
      font-size: 0.8rem;
      cursor: pointer;
    }

    .header .language button:hover {
      background-color: #506273;
    }

    .slider-container {
      width: 95%;
      max-width: 400px;
      overflow: hidden;
      border-radius: 15px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
      background-color: #2b3648;
      position: relative;
      margin: 10px auto;
    }

    .slides {
      display: flex;
      transition: transform 0.5s ease-in-out;
    }

    .slide {
      min-width: 100%;
      position: relative;
    }

    .slide img {
      width: 100%;
      border-radius: 15px 15px 0 0;
    }

    .slide-content {
      position: absolute;
      bottom: 0;
      background: rgba(0, 0, 0, 0.8);
      color: white;
      width: 100%;
      padding: 10px;
      border-radius: 0 0 15px 15px;
    }
    .navigation-dots {
      display: flex;
      justify-content: center;
      margin: 10px 0;
    }

    .dot {
      width: 8px;
      height: 8px;
      background-color: #555;
      margin: 0 5px;
      border-radius: 50%;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .dot.active {
      background-color: #ffa726;
    }

    /* Mobile Responsive Design */
    @media (min-width: 769px) {
      body {
        display: none; /* Hides the design on screens larger than mobile */
      }
    }

    @media (max-width: 769px) {
      .slider-container {
        max-width: 100%;
      }
    }

    /* Product Grid Styles */
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 15px;
      padding: 20px;
    }

    .product {
      background-color: #2d3e52;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      text-align: center;
      position: relative;
      cursor: pointer; /* Make the product card clickable */
    }

    .product img {
      width: 120px;
      height: auto;
      margin-bottom: 10px;
    }

    .product .badge {
      position: absolute;
      top: -10px;
      right: -10px;
      background-color: #f77f00;
      color: white;
      font-size: 12px;
      padding: 5px 10px;
      border-radius: 20px;
    }

    .product h3 {
      color: white;
      font-size: 14px;
      margin: 10px 0;
      font-weight: normal;
    }

    .product-price {
      font-size: 1.2rem;
      color: white;
      font-weight: bold;
    }

    @media (max-width: 768px) {
      .product-grid {
        grid-template-columns: repeat(2, 1fr);
        padding: 10px;
      }
      .product img {
        width: 80px;
      }
      .product h3 {
        font-size: 12px;
      }
    }

    @media (max-width: 480px) {
      .product-grid {
        grid-template-columns: repeat(2, 1fr);
        padding: 10px;
      }
      .product {
        padding: 10px;
      }
      .product img {
        width: 60px;
      }
      .product h3 {
        font-size: 10px;
      }
    }

    .product-card {
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 15px;
      max-width: 400px;
      background-color: #162447;
      box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
    }

    .product-heading {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .product-description {
      font-size: 1rem;
      color: #fff;
      margin-bottom: 20px;
    }

    .input-bar {
      display: flex;
      align-items: center;
      border: 2px solid #ffaa00;
      border-radius: 8px;
      background-color: #0f3460;
      margin-top: 15px;
      height: 40px;
      overflow: hidden;
    }

    .input-icon {
      background-color: #ffaa00;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 50px;
      height: 100%;
    }

    .input-icon img {
      width: 20px;
      height: 20px;
    }

    .input-field {
      flex: 1;
      border: none;
      outline: none;
      background-color: transparent;
      color: #fff;
      font-size: 1rem;
      padding-left: 10px;
    }

    .input-field::placeholder {
      color: #ccc;
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="logo">
      Uni<span>Pin</span>
    </div>
    <div class="language">
      <a href="https://ibb.co/hRBcqhcP"><img src="https://i.ibb.co/N69r4Qr8/1200px-Flag-of-India-svg.png" alt="India Flag"></a>
      <button>EN</button>
    </div>
  </header>
  <div class="slider-container">
    <div class="slides">
      <div class="slide"><img src="https://i.ibb.co/0p9b0ktJ/product.png" alt="Slide 1"></div>
      <div class="slide"><img src="https://i.ibb.co/0p9b0ktJ/product.png" alt="Slide 2"></div>
    </div>
    <div class="navigation-dots">
      <div class="dot active"></div>
      <div class="dot"></div>
    </div>
    <div class="product-card" style="width: 95%; max-width: 435px; background-color: #2b3648; border: none;">
      <h3 class="product-heading" style="color: white;">100 DIAMOND + 60 BONUS DIAMOND</h3>
      <p class="product-price">₹70.00</p>
      <div class="input-bar">
        <div class="input-icon"><a href="https://ibb.co/35JnvHVG"><img src="https://i.ibb.co/Y4rxXGJY/user.png" alt="User Icon"></a></div>
        <input type="text" class="input-field" placeholder="ENTER UID">
      </div>
      <a href="../payment100" style="text-decoration: none;">
        <button style="background-color: #ffaa00; color: white; border: none; border-radius: 5px; padding: 10px 15px; cursor: pointer; margin-top: 10px; display: block; margin-left: auto; margin-right: auto;">Proceed to Buy</button>
      </a>
    </div>
  </div>
  <div class="product-grid">
    <div class="product" onclick="window.location.href='3200Diamond.php';">
      <div class="badge">₹549.00 Only</div>
      <img src="https://i.ibb.co/r2pc42Rh/uc77.png" alt="Product Image">
      <h3>3200 DIAMOND + 950 Bonus DIAMOND</h3>
    </div>
    <div class="product" onclick="window.location.href='8000Diamond.php';">
      <div class="badge">₹899.00 Only</div>
      <img src="https://i.ibb.co/r2pc42Rh/uc77.png" alt="Product Image">
      <h3>8000 DIAMOND + 2800 Bonus DIAMOND</h3>
    </div>
    <div class="product" onclick="window.location.href='100Diamond.php';">
      <div class="badge">₹99.00 Only</div>
      <img src="https://i.ibb.co/r2pc42Rh/uc77.png" alt="Product Image">
      <h3>100 DIAMOND + 60 Bonus DIAMOND</h3>
    </div>
    <div class="product" onclick="window.location.href='300Diamond.php';">
      <div class="badge">₹199.00 Only</div>
      <img src="https://i.ibb.co/r2pc42Rh/uc77.png" alt="Product Image">
      <h3>300 DIAMOND + 25 Bonus DIAMOND</h3>
    </div>
  </div>
  <footer>
    <a href="https://ibb.co/dJrLnXR1"><img src="https://i.ibb.co/VptQXbsr/2footer-1.jpg" alt="Footer Image" style="width: 100%; height: auto;"></a>
  </footer>
  <script>
    const slides = document.querySelector('.slides');
    const dots = document.querySelectorAll('.dot');
    let currentIndex = 0;

    function updateSlider() {
      slides.style.transform = `translateX(-${currentIndex * 100}%)`;
      dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentIndex);
      });
    }

    function moveToNextSlide() {
      currentIndex = (currentIndex + 1) % dots.length;
      updateSlider();
    }

    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        currentIndex = index;
        updateSlider();
      });
    });

    setInterval(moveToNextSlide, 3000); // Change slide every 3 seconds
  </script>
</body>
</html>
