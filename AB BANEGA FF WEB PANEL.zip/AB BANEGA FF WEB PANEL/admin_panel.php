<?php
// Define the path to the 'upi.txt' file
$file_path = 'upi.txt';

// Hardcoded admin password (change this to your desired password)
$admin_password = 'securepassword123';

// Initialize variables
$upiId = $siteName = '';
$successMessage = $errorMessage = '';

// Check if the file exists and read current values
if (file_exists($file_path)) {
    $file_contents = file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $upiId = $file_contents[0] ?? '';
    $siteName = $file_contents[1] ?? '';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUpiId = trim($_POST['upiId']);
    $newSiteName = trim($_POST['siteName']);
    $password = trim($_POST['password']);

    // Validate password
    if ($password !== $admin_password) {
        $errorMessage = "Invalid password. Please try again.";
    } elseif (empty($newUpiId) || empty($newSiteName)) {
        $errorMessage = "Both UPI ID and Site Name are required.";
    } else {
        // Update the file with new values
        $newContent = implode(PHP_EOL, [
            $newUpiId,
            $newSiteName,
            $file_contents[2] ?? '', // Preserve existing transactionRef
            $file_contents[3] ?? '', // Preserve existing merchantCode
        ]);

        if (file_put_contents($file_path, $newContent)) {
            $successMessage = "UPI ID and Site Name updated successfully!";
            $upiId = $newUpiId;
            $siteName = $newSiteName;
        } else {
            $errorMessage = "Failed to update the file. Please check permissions.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px auto;
            max-width: 600px;
            text-align: center;
        }
        form {
            margin-top: 20px;
        }
        input[type="text"], input[type="password"] {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        .message {
            margin-top: 20px;
            font-size: 16px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>
    <p>Use this panel to update the UPI ID and Site Name. A password is required to make changes.</p>
    <form method="POST">
        <input type="text" name="upiId" placeholder="Enter UPI ID" value="<?= htmlspecialchars($upiId) ?>" required>
        <input type="text" name="siteName" placeholder="Enter Site Name" value="<?= htmlspecialchars($siteName) ?>" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <button type="submit">Update</button>
    </form>

    <?php if (!empty($successMessage)): ?>
        <div class="message success"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>
    <?php if (!empty($errorMessage)): ?>
        <div class="message error"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>
</body>
</html>
